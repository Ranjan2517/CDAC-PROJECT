package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Login;
import com.example.demo.entities.Vendor;
import com.example.demo.repositories.LoginRepository;
import com.example.demo.repositories.VendorRepository;

import jakarta.transaction.Transactional;

@Service
public class LoginService {
	@Autowired
    LoginRepository lrepo;
	
	@Autowired
	VendorRepository vrepo;
	
	public Login getLogin(String username,String password_hash) {
		Login l;
		Optional<Login> ol=lrepo.getLogin(username, password_hash);
		System.out.println(ol+"*************");
		try {
			l=ol.get();
		}
		catch(Exception e) {
			l=null;
		}
		return l;
	}
	
	
	@Transactional
    public Login saveLogin(Login login) {
        try {
            return lrepo.save(login);
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception stack trace
            throw new RuntimeException("Error saving login information.", e);
        }
    }
	
	 public Login getById(int loginId) {
	        try {
	            return lrepo.findById(loginId).get();
	        } catch (Exception e) {
	            e.printStackTrace(); // Log the exception stack trace
	            throw new RuntimeException("Error getting login information by ID.", e);
	        }
	    }
	 
//	 public void approveLogin(int login_id) {
//	        // Fetch the login by ID
//	        Login login = lrepo.findById(login_id).get();
//	               
//
//	        // Perform any business logic related to approving the login
//	        login.setStatus_approve(true);
//
//	        // Save the updated login entity
//	        lrepo.save(login);
//	    }

	    public void rejectLogin(int login_id) {
	        // Fetch the login by ID
	        Login login = lrepo.findById(login_id).get();
	               

	        // Perform any business logic related to rejecting the login
	        login.setStatus_approve(false);

	        // Save the updated login entity
	        lrepo.save(login);
	    }

	    
	    public void approveLogin(int login_id) {
	        lrepo.findById(login_id).ifPresent(login -> {
	            // Perform the approval logic here
	            // For example, set an approval status field on the Login entity
	            login.setStatus_approve(true);
	            lrepo.save(login);
	        });
	        // If the login is not present, no need to explicitly handle it
	    }
	 
//	 public void rejectLogin(int login_id) {
//	        // Fetch the login by ID
//	        Login login = lrepo.findById(login_id).orElse(null);
//
//	        if (login != null) {
//	            // Perform any business logic related to rejecting the login
//	            login.setStatus_approve(null); // Set to null when rejected
//
//	            // Save the updated login entity
//	            lrepo.save(login);
//	        }
//	    }
//
//	    public void approveLogin(int login_id) {
//	        lrepo.findById(login_id).ifPresent(login -> {
//	            // Perform the approval logic here
//	            // For example, set an approval status field on the Login entity
//	            login.setStatus_approve(true);
//	            lrepo.save(login);
//	        });
//	        // If the login is not present, no need to explicitly handle it
//	    }
	    
//	    public List<Long> findLoginIdsWithStatusZero() {
//	        return lrepo.findLoginIdsWithStatusZero();
//	    }
}
	 
	


