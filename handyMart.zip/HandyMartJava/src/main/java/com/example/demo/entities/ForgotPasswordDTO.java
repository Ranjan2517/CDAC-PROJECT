package com.example.demo.entities;

public class ForgotPasswordDTO {
    private String emailOrUsername;

    // Getters and setters
    public String getEmailOrUsername() {
        return emailOrUsername;
    }

    public void setEmailOrUsername(String emailOrUsername) {
        this.emailOrUsername = emailOrUsername;
    }
}