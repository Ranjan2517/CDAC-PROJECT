import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const PaymentPage = () => {
  const [cart, setCart] = useState(null);
  const [gmail, setGmail] = useState('');
  const customerId = useSelector((state) => state.user.customerId);
  const cartId = useSelector((state) => state.user.cartId);
  const navigate = useNavigate();

  useEffect(() => {
    console.log('Customer ID from Redux:', customerId);
    console.log('Cart ID from Redux:', cartId);

    if (cartId !== null) {
      console.log('Fetching cart data...');
      fetch(`http://localhost:8080/getCart/${customerId}`)
        .then((response) => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then((data) => {
          console.log('Cart data fetched successfully:', data);
          setCart(data);
        })
        .catch((error) => console.error('Error fetching cart data:', error));
    } else {
      console.log('Cart ID is null, skipping fetch.');
    }
  }, [cartId, customerId]);

  const handleDownloadPDF = () => {
    console.log('Downloading PDF invoice...');
    const input = document.getElementById('cart-content');
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF();
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      let heightLeft = imgHeight;

      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`cart_invoice_${cart.cartId}.pdf`);
      console.log('PDF invoice downloaded successfully');
    });
  };

  const handleSendReceiptEmail = () => {
    console.log('Preparing to send receipt via email...');
    const input = document.getElementById('cart-content');
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF();
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      let heightLeft = imgHeight;

      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      // Generate the PDF as a Blob
      const pdfBlob = pdf.output('blob');
      console.log('PDF generated successfully as Blob:', pdfBlob);

      // Prepare form data to send via API
      const formData = new FormData();
      formData.append('to', gmail); // use gmail from state
      formData.append('subject', 'Your Payment Receipt');
      formData.append('body', 'Please find attached your payment receipt.');
      formData.append('attachment', pdfBlob, `cart_invoice_${cart.cartId}.pdf`);

      console.log('Sending email with the following details:');
      console.log('To:', gmail);
      console.log('Subject:', 'Your Payment Receipt');
      console.log('Form Data:', formData);

      // Make API request to send email
      fetch('http://localhost:8080/api/mail/sendWithAttachment', {
        method: 'POST',
        body: formData,
      })
        .then(response => response.text())
        .then(data => {
          console.log('Email sent successfully:', data);
          alert('Email sent successfully!');
        })
        .catch(error => {
          console.error('Error sending email:', error);
          alert('Email sent successfully!');
        });
    });
  };

  const handleFeedbackNavigation = () => {
    console.log('Navigating to customer home page...');
    navigate(`/customer-home/${customerId}`);
  };

  if (!cart) {
    console.log('Cart data is not available, displaying loading message.');
    return <div>Loading cart...</div>;
  }

  const totalAmount = cart.items.reduce((sum, item) => sum + item.price, 0);
  console.log('Total amount calculated:', totalAmount);

  return (
    <div className="container mt-3">
      <h2>Payment Page</h2>
      <div className="mb-4">
        <h4>Customer ID: {customerId !== null ? customerId : 'Not available'}</h4>
        <h4>Cart ID: {cartId !== null ? cartId : 'Not available'}</h4>
      </div>
      <h3>Invoice</h3>
      <div id="cart-content">
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Item Name</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {cart.items.map((item) => (
              <tr key={item.cartItemId}>
                <td>{item.categories.categoryName}</td>
                <td>{item.quantity}</td>
                <td>${(item.price / item.quantity).toFixed(2)}</td>
                <td>${(item.quantity * (item.price / item.quantity)).toFixed(2)}</td>
              </tr>
            ))}
            <tr>
              <td colSpan="3" className="text-right"><strong>Total Amount:</strong></td>
              <td>${totalAmount.toFixed(2)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <button className="btn btn-primary mt-3" onClick={handleDownloadPDF}>
        Download PDF Invoice
      </button>
      <div className="mt-3">
        <label htmlFor="gmail">Enter Gmail to send receipt:</label>
        <input
          type="email"
          id="gmail"
          className="form-control"
          value={gmail}
          onChange={(e) => setGmail(e.target.value)}
        />
      </div>
      <button className="btn btn-info mt-3" onClick={handleSendReceiptEmail}>
        Send Receipt via Email
      </button>
      <button className="btn btn-secondary mt-3" onClick={handleFeedbackNavigation}>
        GO TO Home
      </button>
    </div>
  );
};

export default PaymentPage;
