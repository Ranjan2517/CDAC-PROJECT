// src/components/UpdateProduct.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const UpdateProduct = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState({
    productName: '',
    subProductName: '',
    description: '',
    price: '',
    inventory: '',
    subCategoryName: '',
  });

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await fetch(`http://localhost:8080/byVendorId/${id}`);
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        setProduct({
            id:id,
          productName: data.productName || '',
          subProductName: data.subcategory_name || '',
          description: data.description || '',
          price: data.price || '',
          inventory: data.inventory || '',
          subCategoryName: data.category_name || '',
        });
      } catch (error) {
        console.error('Error fetching product:', error);
      }
    };
    fetchProduct();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct(prevProduct => ({ ...prevProduct, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    console.log('Product being sent to update:', product);
  
    try {
      const response = await fetch('http://localhost:8080/update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(product),
      });
  
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Network response was not ok. Status: ${response.status}. Error: ${errorText}`);
      }
  
      const contentType = response.headers.get('Content-Type');
      let responseData;
  
      if (contentType && contentType.includes('application/json')) {
        responseData = await response.json();
      } else {
        responseData = await response.text();
      }
  
      console.log('Response Data:', responseData);
      navigate('/vendor-home');
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };
  

  return (
    <div className="container mt-3">
      <h2 className="mb-4">Update Product</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="productName" className="form-label">Product Name</label>
          <input
            type="text"
            className="form-control"
            id="productName"
            name="productName"
            value={product.productName || ''}  // Provide a default value
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="subProductName" className="form-label">Sub Product Name</label>
          <input
            type="text"
            className="form-control"
            id="subProductName"
            name="subProductName"
            value={product.subProductName || ''} // Corrected and provided default value
            onChange={handleChange}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="description" className="form-label">Description</label>
          <textarea
            className="form-control"
            id="description"
            name="description"
            value={product.description || ''}
            onChange={handleChange}
            rows="3"
            required
          ></textarea>
        </div>
        <div className="mb-3">
          <label htmlFor="price" className="form-label">Price</label>
          <input
            type="number"
            className="form-control"
            id="price"
            name="price"
            value={product.price || ''}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="inventory" className="form-label">Inventory</label>
          <input
            type="number"
            className="form-control"
            id="inventory"
            name="inventory"
            value={product.inventory || ''}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="subCategoryName" className="form-label">Sub Category Name</label>
          <input
            type="text"
            className="form-control"
            id="subCategoryName"
            name="subCategoryName"
            value={product.subCategoryName || ''}  // Provided a default value
            onChange={handleChange}
          />
        </div>
        <button type="submit" className="btn btn-primary">Update Product</button>
      </form>
    </div>
  );
};

export default UpdateProduct;
